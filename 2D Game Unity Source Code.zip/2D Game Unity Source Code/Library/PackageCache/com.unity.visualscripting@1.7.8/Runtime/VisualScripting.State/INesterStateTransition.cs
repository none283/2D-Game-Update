namespace Unity.VisualScripting
{
    public interface INesterStateTransition : IStateTransition, IGraphNesterElement { }
}
