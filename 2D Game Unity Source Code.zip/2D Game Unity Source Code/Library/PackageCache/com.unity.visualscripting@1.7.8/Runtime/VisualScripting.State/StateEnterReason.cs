namespace Unity.VisualScripting
{
    public enum StateEnterReason
    {
        Start,
        Branch,
        Forced
    }
}
