namespace Unity.VisualScripting
{
    public interface INesterUnit : IUnit, IGraphNesterElement { }
}
