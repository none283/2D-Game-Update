namespace Unity.VisualScripting
{
    [TypeIconPriority]
    public interface IApplicationVariableUnit : IVariableUnit { }
}
