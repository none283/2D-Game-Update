namespace Unity.VisualScripting
{
    public interface IGraphVariableUnit : IVariableUnit { }
}
