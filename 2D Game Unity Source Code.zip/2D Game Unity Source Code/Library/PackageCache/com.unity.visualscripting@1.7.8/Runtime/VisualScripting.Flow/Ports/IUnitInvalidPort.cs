namespace Unity.VisualScripting
{
    public interface IUnitInvalidPort : IUnitPort
    {
    }
}
