namespace Unity.VisualScripting
{
    public interface IUnitOutputPortDefinition : IUnitPortDefinition { }
}
