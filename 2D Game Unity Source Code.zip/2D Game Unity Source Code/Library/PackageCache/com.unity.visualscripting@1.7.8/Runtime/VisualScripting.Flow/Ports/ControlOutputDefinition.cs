namespace Unity.VisualScripting
{
    public sealed class ControlOutputDefinition : ControlPortDefinition, IUnitOutputPortDefinition { }
}
