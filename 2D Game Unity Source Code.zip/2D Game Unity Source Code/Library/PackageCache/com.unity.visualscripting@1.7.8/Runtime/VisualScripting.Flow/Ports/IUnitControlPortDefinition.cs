namespace Unity.VisualScripting
{
    public interface IUnitControlPortDefinition : IUnitPortDefinition { }
}
