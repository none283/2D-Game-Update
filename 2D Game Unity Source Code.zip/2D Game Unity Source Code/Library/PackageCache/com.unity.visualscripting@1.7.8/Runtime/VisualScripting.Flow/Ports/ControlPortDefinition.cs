namespace Unity.VisualScripting
{
    public abstract class ControlPortDefinition : UnitPortDefinition, IUnitControlPortDefinition
    { }
}
