namespace Unity.VisualScripting
{
    public interface IUnitInputPortDefinition : IUnitPortDefinition { }
}
